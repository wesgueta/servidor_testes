#!/bin/sh
php /home/aindex/www/cubesat/teste_post/etc/crontab/deletar.php