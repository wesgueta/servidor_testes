<?php

echo phpinfo();
?>